import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <homepage />
      <header>
        <h1>Dependendaltics</h1>
      </header>
      <main>
        <p>Dependency Detector for C++</p>
      </main>
      <footer>
      <div className="footer-content">
        <p>&copy; 2023 MySite.com</p>
      </div>
      <FooterSection />
    </footer>
    </div>
  );

}

export default App;