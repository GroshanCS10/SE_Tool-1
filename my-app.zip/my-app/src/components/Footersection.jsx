import React from 'react';

function FooterSection() {
  return (
    <section id="1144">
      <h2>Additional Information</h2>
      <ul>
        <li>About Us</li>
        <li>Contact Us</li>
        <li>Privacy Policy</li>
      </ul>
    </section>
  );
}

export default FooterSection;
