import React from 'react';
import FooterSection from './FooterSection';

function Footer() {
  return (
    <footer>
      <div className="footer-content">
        <p>&copy; 2023 MySite.com</p>
      </div>
      <FooterSection />
    </footer>
  );
}

export default Footer;
